#include "PreviewPanel.h"

#include <imgui.h>

using namespace ui::panels;

void PreviewPanel::Render()
{
    ImGui::TextUnformatted("Preview panel (not implemented)");
    ImGui::TextUnformatted("This is a placeholder for an off-screen simulation preview.");
}
