#pragma once

enum class EditorMode {
    Template = 0,
    Scene = 1
};
